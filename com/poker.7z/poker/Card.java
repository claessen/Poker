package com.poker;

public class Card {

	Rank myRank;
	Suit mySuit;
	
	public Card(Rank r, Suit s) {
		myRank = r;
		mySuit = s;
	}
	
	public String toString() {
		
		return this.myRank.name() + " of " + this.mySuit.name();
		
	}

	
	
// Works
//	@Override
//	public int compareTo(Card o) {
//		return this.myRank.rank - o.myRank.rank;
//	}
	

}
