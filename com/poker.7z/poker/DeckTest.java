package com.poker;

import static org.junit.Assert.*;

import org.junit.Test;

public class DeckTest {

	@Test
	public void ADeckShouldHave52Cards() {
		Deck d = new Deck();
		int cardCount = 0;
		d.
		for (Card c : d) { cardCount++);
		fail("Not yet implemented");
	}

}
