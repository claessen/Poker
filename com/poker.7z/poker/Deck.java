package com.poker;

import java.util.ArrayList;

public class Deck {
	ArrayList<Card> Deck = new ArrayList<Card>();
	
	Deck() {
		for (Rank r : Rank.values()) {
			for (Suit s : Suit.values()) {
				Card c = new Card(r, s);
				Deck.add(c);
			}
		}
	}
	
	
	public String toString() {
		StringBuilder cards = new StringBuilder();
		for (Card c : Deck) {
			cards.append(c.toString() + " ");
		}
		return cards.toString();
	}
}
