package com.poker;

import java.util.Arrays;

public class SortHandTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Hand myHand = new Hand();
		Card myCard1 = new Card(Rank.DEUCE, Suit.HEARTS);
		Card myCard2 = new Card (Rank.JACK, Suit.CLUBS);
		Card myCard3 = new Card (Rank.SEVEN, Suit.HEARTS);
		Card myCard4 = new Card (Rank.KING, Suit.HEARTS);

		myHand.addCard(myCard1);
		myHand.addCard(myCard2);
		myHand.addCard(myCard3);
		myHand.addCard(myCard4);
		
		System.out.println(myHand);
		
		myHand.sortByRank();
	
		System.out.println("Sorted by rank...");
		System.out.println(myHand);
		
		
		myHand.sortBySuit();
	
		System.out.println("Sorted by suit...");
		System.out.println(myHand);
		
		Deck d = new Deck();
		System.out.println(d);
		
		

	}

}
